#!/usr/bin/env bash
# ============================================================
# workbuddy2api 管理脚本（复用 WorkBuddy 登录态 → OpenAI 兼容 API）
# 端口 8787，原生 tool calling，支持流式 SSE
# 用法: ./start-wb2api.sh {start|status|stop|restart|logs}
# ============================================================
set -e
cd "$(dirname "$0")"

VENV_PY=".venv/Scripts/python.exe"
LOG_FILE="converter.log"
PID_FILE="converter.pid"
PORT="8787"

case "${1:-status}" in
  start)
    if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
      echo "[OK] 已在运行 (PID $(cat "$PID_FILE"))"
    else
      "$VENV_PY" converter.py --desensitize --log "$LOG_FILE" > /dev/null 2>&1 &
      echo $! > "$PID_FILE"
      sleep 5
      if curl -s -m 5 "http://127.0.0.1:${PORT}/health" | grep -q '"status":"ok"'; then
        echo "[OK] workbuddy2api 已启动，监听 http://127.0.0.1:${PORT}/v1（原生 tool calling）"
      else
        echo "[!] 启动可能失败，请查看 $LOG_FILE"
      fi
    fi
    ;;
  status)
    if [ -f "$PID_FILE" ] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
      echo "[OK] 运行中 (PID $(cat "$PID_FILE"))"
      curl -s -m 5 "http://127.0.0.1:${PORT}/health"
      echo
    else
      echo "[-] 未运行"
    fi
    ;;
  stop)
    if [ -f "$PID_FILE" ]; then
      kill "$(cat "$PID_FILE")" 2>/dev/null && rm -f "$PID_FILE" && echo "[OK] 已停止"
    else
      echo "[-] 未在运行"
    fi
    ;;
  restart)
    "$0" stop; sleep 1; "$0" start
    ;;
  logs)
    tail -f "$LOG_FILE" 2>/dev/null || echo "[-] 无日志文件"
    ;;
  *)
    echo "用法: $0 {start|status|stop|restart|logs}"
    ;;
esac
