# ===== backend/config/llm_factory.py 中 codebuddy 分支（参考） =====
# 依赖：langchain-openai 包

def _create_codebuddy_llm(settings):
    from langchain_openai import ChatOpenAI
    return ChatOpenAI(
        model=settings.codebuddy_model,
        api_key=settings.codebuddy_api_key or "codebuddy-local",  # workbuddy2api 默认不校验 Key
        base_url=settings.codebuddy_base_url,                      # http://127.0.0.1:8787/v1
        temperature=settings.llm_temperature,
    )
